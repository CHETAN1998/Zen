
# """
# Shows basic usage of the Google Calendar API. Creates a Google Calendar API
# service object and outputs a list of the next 10 events on the user's calendar.
# """
from __future__ import print_function
from apiclient.discovery import build
from httplib2 import Http
from oauth2client import file, client, tools
import datetime

import os
import signal

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk
gi.require_version('AppIndicator3', '0.1')
from gi.repository import AppIndicator3 as appindicator
# gi.require_version('Notify', '0.7')
# from gi.repository import Notify
import notify2 as Notify

# Google search open in new Tab
import webbrowser

from pynput.keyboard import Key, Listener, KeyCode
from pynput import keyboard

import tkinter as Tk

import speech_recognition as sr

import vlc
import time
from fnmatch import fnmatch


APPINDICATOR_ID = 'zenAppIndicator'

def main():
	indicator = appindicator.Indicator.new(
					APPINDICATOR_ID, os.path.abspath('app_indicator.png'), 
					appindicator.IndicatorCategory.SYSTEM_SERVICES)

	indicator.set_status(appindicator.IndicatorStatus.ACTIVE)
	# build_menu() called
	indicator.set_menu(build_menu())

	Gtk.main()


current = set()

saveTextSK = set( [format(Key.ctrl_l), format(keyboard.KeyCode(char = 'c'))] )

def reader_mode(_):
	print("hi")
	def on_press(key):
		# print('{0} pressed' . format(key))

		current.add(format(key))
		print("current: " + str(current))
		print("saveTextSK: " + str(saveTextSK) )
		if current == saveTextSK:
			saveText()
			# print("Finally!")

	def on_release(key):
		# print('{0} release' . format(key))

		global current
		if key in current:
			current.remove(format(key))

		# print(str(current))
		current = set()

		if key == Key.esc:
			# Stop listener
			return False

	# Collect events until released
	with Listener(
			on_press=on_press,
			on_release=on_release) as listener:
		listener.join()

def processData(data):
	print(data + "\n\n")

def saveText():
	form = Tk.Tk()
	# previousData = form.clipboard_get()
	# while True:
	data = form.clipboard_get()
	# if data != previousData:
	processData(data)
	# previousData = data
	form.destroy()



def build_menu():
	menu = Gtk.Menu()

	# CLI -> Access the command line interface
	item_cli = Gtk.MenuItem('CLI')
	item_cli.connect('activate', cli)
	menu.append(item_cli)

	# VUI -> Access the Voice User Interface
	item_vui = Gtk.MenuItem('VUI')
	item_vui.connect('activate', vui)
	menu.append(item_vui)

	# reader mode on
	item_read_mode = Gtk.MenuItem('reader mode')
	item_read_mode.connect('activate', reader_mode)
	menu.append(item_read_mode)

	# help
	item_cli = Gtk.MenuItem('Help')
	item_cli.connect('activate', showHelp)
	menu.append(item_cli)

	# Quit / Close / Stop the Application
	item_quit = Gtk.MenuItem('Quit')
	item_quit.connect('activate', quit)
	menu.append(item_quit)

	menu.show_all()
	return menu


def cli(_):
	class cliWindow(Gtk.Window):
		
		def __init__(self):
			Gtk.Window.__init__(self, title="Zen")
			self.set_border_width(15)
			self.set_size_request(width=500, height=50)
			
			hbox = Gtk.Box(spacing=20)
			hbox.set_homogeneous(False)

			vbox_left = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
			vbox_left.set_homogeneous(False)
			vbox_right = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
			vbox_right.set_homogeneous(False)
			
			hbox.pack_start(vbox_left, True, True, 0)
			hbox.pack_start(vbox_right, True, True, 0)
			
			# label corresponding to CLI insert command
			label = Gtk.Label(" /<-Command->\ ")
			vbox_left.pack_start(label, True, True, 0)

			# Text Box
			commandEntry = Gtk.Entry()
			commandEntry.set_text("Enter Command to Execute: ")
			vbox_left.pack_start(commandEntry, True, True, 0)
			commandEntry.set_size_request(width=400, height=8)
			commandEntry.connect("activate", self.on_next_clicked, commandEntry)

			# next button
			nextButton = Gtk.Button(label="Next-> ")
			nextButton.connect("clicked", self.on_next_clicked, commandEntry)
			vbox_right.pack_start(nextButton, True, True, 0)

			self.add(hbox)

		def on_next_clicked(self, button, commandEntry):
			inputText = commandEntry.get_text()
			executeFunction(self, inputText)

	win = cliWindow()
	win.connect("destroy", Gtk.main_quit)
	win.show_all()
	Gtk.main()

def vui(_):
	r = sr.Recognizer()
	m = sr.Microphone()

	try:
		print("A moment of silence, please...")
		while True:
			with m as source: r.adjust_for_ambient_noise(source)
			# print("Set minimum energy threshold to {}".format(r.energy_threshold))
		
			r.energy_threshold += 250
		
			# print("Say something!")
			with m as source: audio = r.listen(source, None)
			# print("Got it! Now to recognize it...")
			try:
				# recognize speech using Google Speech Recognition
				value = r.recognize_google(audio)

				# we need some special handling here to correctly print unicode characters to standard output
				if str is bytes:  # this version of Python uses bytes for strings (Python 2)
					print(u"You said {}".format(value).encode("utf-8"))
					value = format(value).encode("utf-8");
				else:  # this version of Python uses unicode for strings (Python 3+)
					print("You said {}".format(value))
					value = format(value)
				
				msg(value)		
				
				ip = value
				ip = ip.split()
				
				option = ip[0]
				del ip[0]

				if option == "search":
					searchText = " ".join(ip)
					# print(searchText)
					search(searchText)
					print("search complete!")
					# return True
	
				if option == "calender":
					option = ip[0]
					del ip[0]

					if option == "schedule":
						schedule = get_schedule()
						msg(schedule)
						print("schedule fetched!")
	
					option += " " + ip[0]
					del ip[0]
					if option == "add entry":
						text = " ".join(ip)
						schedule = add_entry(text)
						msg(schedule)
						print("calender entry made successfully!")

				if option == "create":
					playlistName = ip[0]
					del ip[0]
					playlistLocation = " ".join(ip)

					create_playlist(playlistName, playlistLocation)
					print("Playlist Created")

				if option == "play":
					playlistName = ip[0]
					del ip[0]

					print(playlistName + " playing.")
					play_playlist(playlistName)
					

				if option == "delete":
					playlistName = ip[0]
					
					print(playlistName + " deleted.")
					delete_playlist(playlistName)


					

				"""
				if num[0] == "search":
					searchStr = ""
					for i in range(len(num)):
						if i != 0:
							searchStr += num[i]
			
					import webbrowser
					new = 2
					tabUrl = "http://google.com?#q="
					term = searchStr
					webbrowser.open(tabUrl+term, new=new)

				elif len(num) == 3:
					try:
						a = int(num[0])
					except:
						continue
					op = num[1].lower()
					b = int(num[2])

					if op == 'multiplied' or op == 'multiplied by' or op == 'into' or op =='x':
						print(a*b)
					elif op == 'divided' or op == 'divided by' or op == '/':
						print(a/b)
					elif op == 'plus' or op == '+':
						print(a+b)
					elif op == 'subtract' or op == '-':
						print(a-b)
				"""
		
			except sr.UnknownValueError:
				print("Oops! Didn't catch that")
			except sr.RequestError as e:
				print("Uh oh! Couldn't request results from Google Speech Recognition service; {0}".format(e))
	except KeyboardInterrupt:
		pass


def create_playlist (name, location):
	fo = open("foo.txt", "a")
	string = name + " " + location + "\n"
	print("create: " + string)
	fo.write(string)

def play_playlist (name):
	fo = open("foo.txt", "r")
	with open('foo.txt') as f:
		content = f.readlines()
	content = [x.strip() for x in content]
	i = 0
	while(True):	
		pqr = content[i].split(' ')
		if (pqr[0] == name):
			del pqr[0]
			location = " ".join(pqr)
			break
		i = i + 1
	#song_list=['/home/chetan/Project SE/track1.mp3','/home/chetan/Project SE/track2.mp3']
	lines = [line.rstrip(':') for line in open('foo.txt')]
	#print (lines)
	instance=vlc.Instance()
	#mydir = "/home/chetan/Music/Music"
	mydir = location
	song_list = [file for file in os.listdir(mydir) if fnmatch(file, '*.mp3')]
	#print('file_list {}'.format(song_list))
	time.sleep(2)
	# os.chdir("/home/chetan/Music/Music") 
	os.chdir(location) 
	for song in song_list:
		player=instance.media_player_new()
		media=instance.media_new(song)
		#print ("playing" + song)
		media.get_mrl()
		player.set_media(media)
		player.play()
		playing = set([1,2,3,4])
		time.sleep(1) #Give time to get going
		duration = player.get_length() / 1000
		mm, ss = divmod(duration, 60)
		print ("Playing", song, "Length:", "%02d:%02d" % (mm,ss) )
		while True:
			state = player.get_state()
			if state not in playing:
				break
			continue

def delete_playlist (name):
	fo = open("foo.txt", "r")
	with open('foo.txt') as f:
		content = f.readlines()
	content = [x.strip() for x in content]
	i = 0
	while(True):	
		pqr = content[i].split(' ')
		if (pqr[0] == name):
			break
		i = i+1
	del_line = i    #line to be deleted: no. 3 (first line is no. 1)
	with open("foo.txt") as textobj:
		content = textobj.readlines()
	del content[del_line]    #delete regarding element
	#rewrite the textfile from list contents/elements:
	with open("foo.txt","w") as textobj:
		for n in content:
			textobj.write(n)



def executeFunction(self, inputText):
	print(inputText)
	ip = inputText.split()
	if len(ip) <= 1:
		msg("Invalid Input!<br><command> <arguments>")
		return False

	option = ip[0]
	del ip[0]

	if option == "search":
		searchText = " ".join(ip)
		# print(searchText)
		search(searchText)
		return True
	
	if option == "calender":
		option = ip[0]
		del ip[0]

		if option == "schedule":
			schedule = get_schedule()
			msg(schedule)
			return True
	
		option += " " + ip[0]
		del ip[0]
		if option == "add entry":
			text = " ".join(ip)
			schedule = add_entry(text)
			msg(schedule)
			return True

	if option == "create":
		playlistName = ip[0]
		del ip[0]
		playlistLocation = " ".join(ip)
		create_playlist(playlistName, playlistLocation)
		print("Playlist Created")
		return True

	if option == "play":
		playlistName = ip[0]
		del ip[0]

		print(playlistName + " playing.")
		play_playlist(playlistName)
		return True
		

	if option == "delete":
		playlistName = ip[0]
		
		delete_playlist(playlistName)
		print(playlistName + " deleted.")
		return True
	

def search(searchText):
	new = 2
	tabUrl = "http://google.com?#q=";
	webbrowser.open(tabUrl+searchText, new=new)

def get_schedule():

	# Setup the Calendar API
	SCOPES = 'https://www.googleapis.com/auth/calendar'
	store = file.Storage('credentials.json')
	creds = store.get()
	if not creds or creds.invalid:
		flow = client.flow_from_clientsecrets('client_secret.json', SCOPES)
		creds = tools.run_flow(flow, store)
	service = build('calendar', 'v3', http=creds.authorize(Http()))

	# Call the Calendar API
	now = datetime.datetime.utcnow().isoformat() + 'Z' # 'Z' indicates UTC time
	print('Getting the upcoming 10 events')
	events_result = service.events().list(calendarId='primary', timeMin=now,
		                                  maxResults=10, singleEvents=True,
		                                  orderBy='startTime').execute()
	events = events_result.get('items', [])

	result = "";

	if not events:
		result += 'No upcoming events found.'
	for event in events:
		start = event['start'].get('dateTime', event['start'].get('date'))
		result += (start + " " + event['summary'])
		result += "<br>|<br>"

	return result

def add_entry(text):
	# Setup the Calendar API
	SCOPES = 'https://www.googleapis.com/auth/calendar'
	store = file.Storage('credentials.json')
	creds = store.get()
	if not creds or creds.invalid:
		flow = client.flow_from_clientsecrets('client_secret.json', SCOPES)
		creds = tools.run_flow(flow, store)
	service = build('calendar', 'v3', http=creds.authorize(Http()))

	# Refer to the Python quickstart on how to setup the environment:
	# https://developers.google.com/calendar/quickstart/python
	# Change the scope to 'https://www.googleapis.com/auth/calendar' and delete any
	# stored credentials.

	# text ='WST Submission on Apr 15th 11:50pm-11:51pm'
	created_event = service.events().quickAdd(
		calendarId='primary', text=text).execute()

	if created_event['id']:
		return get_schedule()

def showHelp(_):
	pass

def quit(_):
	Gtk.main_quit()

def msg(notificationText):
	print(notificationText)
	Notify.init("Zen")
	n = Notify.Notification("Zen", notificationText)
	n.set_timeout(1500)
	n.show()
	Notify.uninit()

if __name__ == "__main__":
	signal.signal(signal.SIGINT, signal.SIG_DFL)


main()




