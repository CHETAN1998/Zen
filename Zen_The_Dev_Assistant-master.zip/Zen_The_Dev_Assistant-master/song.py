'''
def setplaylist (name, location):
	fo = open("foo.txt", "a")
	string = name + " " + location + "\n"

def playplaylist (name):
	fo = open("foo.txt", "r")
	with open('foo.txt') as f:
		content = f.readlines()
	content = [x.strip() for x in content]
	i = 0
	while(true):	
		pqr = content[i].split(' ')
		if (pqr[0] == name)
			location = pqr[1]
			break
		i++
	import vlc
	import time
	#song_list=['/home/chetan/Project SE/track1.mp3','/home/chetan/Project SE/track2.mp3']
	lines = [line.rstrip(':') for line in open('foo.txt')]
	print (lines)
	instance=vlc.Instance()
	import os
	from fnmatch import fnmatch
	#mydir = "/home/chetan/Music/Music"
	mydir = location
	song_list = [file for file in os.listdir(mydir) if fnmatch(file, '*.mp3')]
	print('file_list {}'.format(song_list))
	time.sleep(2)
	os.chdir("/home/chetan/Music/Music") 
	for song in song_list:
		player=instance.media_player_new()
		media=instance.media_new(song)
		print (song)
		media.get_mrl()
		player.set_media(media)
		player.play()
		playing = set([1,2,3,4])
		time.sleep(1) #Give time to get going
		duration = player.get_length() / 1000
		mm, ss = divmod(duration, 60)
		print ("Playing", song, "Length:", "%02d:%02d" % (mm,ss) )
		while True:
			state = player.get_state()
			if state not in playing:
				break
			continue

#setplaylist("dq", "wq")
#setplaylist("dq", "wq")

fo = open("foo.txt", "a")
#fo.write(string);
with open('foo.txt') as f:
	content = f.readlines()
	# you may also want to remove whitespace characters like `\n` at the end of each line
	content = [x.strip() for x in content] 
	#arr = content.split(',')
#print (content)
'''

'''
name = "das"
fo = open("foo.txt", "r")
with open('foo.txt') as f:
	content = f.readlines()
content = [x.strip() for x in content]
i = 0
while(True):	
	pqr = content[i].split(' ')
	if (pqr[0] == name):
		location = pqr[1]
		break
	i = i + 1
print (location)

'''
def deleteplaylist (name):
	fo = open("foo.txt", "r")
	with open('foo.txt') as f:
		content = f.readlines()
	content = [x.strip() for x in content]
	i = 1
	while(True):	
		pqr = content[i].split(' ')
		if (pqr[0] == name):
			i = i + 1
			break
	del_line = i    #line to be deleted: no. 3 (first line is no. 1)
	with open("foo.txt") as textobj:
		content = textobj.readlines()
	del content[del_line - 1]    #delete regarding element
	#rewrite the textfile from list contents/elements:
	with open("foo.txt","w") as textobj:
		for n in content:
			textobj.write(n)

deleteplaylist("dqwd")

