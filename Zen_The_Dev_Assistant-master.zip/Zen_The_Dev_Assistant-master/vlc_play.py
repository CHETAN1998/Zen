import vlc
import time
#song_list=['/home/chetan/Project SE/track1.mp3','/home/chetan/Project SE/track2.mp3']
instance=vlc.Instance()
import os
from fnmatch import fnmatch
mydir = "/home/chetan/Music/Music"
song_list = [file for file in os.listdir(mydir) if fnmatch(file, '*.mp3')]
print('file_list {}'.format(song_list))
time.sleep(2)
os.chdir("/home/chetan/Music/Music") 
for song in song_list:
    player=instance.media_player_new()
    media=instance.media_new(song)
    print (song)
    media.get_mrl()
    player.set_media(media)
    player.play()
    playing = set([1,2,3,4])
    time.sleep(1) #Give time to get going
    duration = player.get_length() / 1000
    mm, ss = divmod(duration, 60)
    print ("Playing", song, "Length:", "%02d:%02d" % (mm,ss) )
    while True:
        state = player.get_state()
        if state not in playing:
            break
        continue
